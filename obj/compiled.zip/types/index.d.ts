declare module "_102032_/l2/collabLandingPage" {
    /**
     * Class extending LitElement with CollabState functionality.
     */
    export class CollabLandingPage extends HTMLElement {
        createRenderRoot(): this;
        getMessageKey(messages: any): string;
        loadStyle(css: string): void;
    }
    export function getMessageKey(messages: any): string;
}
declare module "_102027_/l2/collabImport" {
    interface CollabImportOptions {
        project: number;
        shortName: string;
        folder: string;
        extension?: '.defs.ts' | '.ts' | '.test.ts';
    }
    export function collabImport(opts: CollabImportOptions): Promise<any>;
}
declare module "_102027_/l2/utils" {
    export function getPath(widget: string): mls.stor.IFileInfoBase | undefined;
    export function convertTagToFileName(tag: string): {
        shortName: string;
        project: number;
        folder: string;
    } | undefined;
    export function convertFileNameToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
}
declare module "_102027_/l2/libCompile" {
    export const getDependenciesByHtmlFile: (file: mls.stor.IFileInfo, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByHtml: (models: mls.editor.IModels, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByMFile: (models: mls.editor.IModels, withCss?: boolean) => Promise<IJSONDependence>;
    export function getAllWebComponentsInSource(source: string): string[];
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        importsLinks: {
            ref: string;
            rel: string;
        }[];
        tokens: string | undefined;
        globalCss: string;
        errors: {
            tag: string;
            error: string;
        }[];
    }
}
declare module "_102027_/l2/libCommom" {
    export function getMyKeysBranch(project: number): {
        branch: string;
        owner: string;
        repo: string;
    };
    export function createPath(project: number, shortName: string, folder: string): string;
    export function generateCompactTimestamp(): string;
    export function getDateFormated(dt: string): string;
    export function changeFavIcon(notification: boolean): void;
    export function checkIfHasLocalProject(): boolean;
    export function getLocalProjectName(): string;
    export function setLocalProjectName(prjName: string): void;
    export function isValidProjectName(name: string): boolean;
    export function escapeHTML(str: string): string;
    export function openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): Promise<void>;
    export function selectLevel(level: number): void;
    export function forceServiceInstance(level: number, service: string): Promise<void>;
    export function loadFileHTMLInContainer(el: HTMLElement, shortName: string, project: number): Promise<void>;
    export function convertColorToHex(color: string): string;
    export function getEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string>;
    export function getStyleEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string | undefined>;
    export function loadPluginProject(project: number, scope: string, onlyEnabled?: boolean): Promise<mls.plugin.MenuAction[]>;
    export function setProjectDetails(project: number): void;
    export function getProjectDetails(): mls.stor.localStor.IRetProjectDetails | undefined;
    export function calculateTotalStringSize(source: string, limitBase: number): ICalculateTotalStringSize;
    export function getListNewFilesToDeleteByFolder(project: number, folder: string, includeDist?: boolean): Promise<mls.stor.IFileInfo[]>;
    export function deleteAllFilesLocal(filesToDelete: mls.stor.IFileInfo[]): AsyncGenerator<string, void, unknown>;
    export function loadModuleFromProjectOrDependency(name: string, folder: string, ext: string): Promise<any>;
    export function findStorFileInProjectsOrDeps(projectActual: number, level: number, fileName: string, folder: string, extension: string): mls.stor.IFileInfo;
    export function saveOpenedFile(project: number, level: number, file: OpenedFile): void;
    export function getLastOpenedFiles(project: number): UserOpenedFiles;
    export function deleteLastOpenedFiles(project: number): void;
    export function getLastModule(): Record<string, string>;
    export function setLastModule(project: number, moduleName: string): void;
    export function getBaseTemplate(file: IInfoFile, enhancement?: string): Promise<string>;
    export function verifyNeedAddTripleslach(info: mls.stor.IFileInfoBase, src: string, extension: string, enhancement?: string): string;
    export function getInstanceByFile(file: mls.stor.IFileInfo): Promise<Object | undefined>;
    export function isNameValid(project: number, shortName: string, folder: string, level: number, extension: string): boolean;
    export function openElementInServiceDetails(el: HTMLElement): Promise<void>;
    export function clearServiceDetails(): Promise<void>;
    export function getProjectConfig(project: number): Promise<IProjectConfig | undefined>;
    export function getProjectModuleConfig(path: string, project: number): Promise<IProjectModuleConfig | undefined>;
    export function getMessageKey(messages: any): string;
    export type OpenedFile = string | OpenedFileL2;
    export type UserOpenedFiles = Record<number, OpenedFile>;
    export type OpenedFileL2 = {
        left?: string;
        right?: string;
    };
    export interface IProjectModuleConfig {
        theme: string;
        initialPage: string;
        menu: IProjectModuleConfigMenu[];
    }
    export interface IProjectModuleConfigMenu {
        pageName: string;
        title: string;
        auth: string;
        icon?: string;
        target?: string;
    }
    export interface IProjectConfigModules {
        name: string;
        path: string;
        pathServer?: string;
        auth: string;
        icon?: string;
    }
    export interface IProjectConfig {
        masterFrontEnd?: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd?: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: IProjectConfigModules[];
    }
    interface ICalculateTotalStringSize {
        totalsize: number;
        exceededLimit: boolean;
        sizeFormatted: string;
    }
    interface IInfoFile {
        project: number;
        folder: string;
        shortName: string;
        extension: string;
    }
}
declare module "_102027_/l2/libMindMap" {
    export const allDefs: Record<string, IdefModule>;
    export function getAllDefs(): Promise<Record<string, IdefModule>>;
    export function getDefsByFile(file: mls.stor.IFileInfo): Promise<mls.defs.AsIs | undefined>;
    export function getMindMapByName(file: string): Promise<MindMapData | undefined>;
    export function getMindMapByStorFile(file: mls.stor.IFileInfo): Promise<MindMapData | undefined>;
    export function setMindMapVariable(bread: MindMapNode[]): void;
    export function getMindMapVariable(): MindMapNode[];
    export type MindMapSelected = MindMapSelectedFile | MindMapSelectedPlugin;
    export interface MindMapSelectedBase {
        plugin: Function;
        args: string;
    }
    export interface MindMapSelectedFile extends MindMapSelectedBase {
        type: "file";
        file: mls.stor.IFileInfo;
        organism?: string;
        widget?: string;
        modelType?: mls.editor.ModelType;
    }
    export interface MindMapSelectedPlugin extends MindMapSelectedBase {
        type: "plugin";
        file: mls.stor.IFileInfo;
    }
    export type MindMapNodeType = 'main' | 'asIs' | 'codeInsights' | 'webcomponent' | 'imports' | 'importedBy' | 'language' | 'attributes' | 'file' | 'file_wc' | 'text' | 'findFile' | 'findFile_item';
    export interface MindMapNode {
        id: string;
        label: string;
        type: MindMapNodeType;
        related: string[];
        meta: Record<string, any>;
        description?: string;
        navigate?: boolean;
    }
    export interface MindMapData {
        current: string;
        nodes: MindMapNode[];
    }
    export interface MindMapNodeStyle {
        fill: string;
        stroke: string;
        text: string;
    }
    export type MindMapNodeStyles = Record<string, MindMapNodeStyle>;
    export interface IdefModule {
        file: mls.stor.IFileInfo;
        defs: mls.defs.AsIs;
    }
}
declare module "_102027_/l2/libModel" {
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): void;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
}
declare module "_102027_/l2/designSystemBase" {
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensFromSource(src: string): string;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
    export interface IDesignSystemTokens {
        description: string;
        themeName: string;
        color: Record<string, string>;
        global: Record<string, string>;
        typography: Record<string, string>;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    interface IKeyValueToken {
        [x: string]: string;
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
}
declare module "_102032_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102027_/l2/designSystemBase";
    export const tokens: IDesignSystemTokens[];
}
declare module "_102027_/l2/propiertiesLit" {
    export function getPropierties(model: mls.editor.IModelTS): mls.l2.enhancement.IProperties[];
    export interface IMember {
        name: string;
        pos: number;
        type: string;
        comment: string;
        modifiers: string[];
        tags: ITag[];
        parameters?: IParameter[];
        initializerText: string;
        initializerType: string;
    }
    export interface ITag {
        name: string;
        pos: number;
        tagName: string;
        comment: string;
    }
    export interface IParameter {
        name: string;
        comment: string;
        type: string;
        modifiers: string[];
    }
    export interface IJSDoc {
        name: string;
        pos: number;
        type: string;
        comment: string;
        members: IMember[];
        tags: ITag[];
    }
    export interface IDecoratorClassInfo {
        decoratorName: string;
        tagName: string;
    }
    export interface IDecoratorItem {
        line: number;
        character: number;
        text: string;
    }
    export interface IDecoratorDetails {
        parentName: string;
        type: string;
        pos: number;
        decorators: IDecoratorItem[];
    }
    export interface IDecoratorDictionary {
        [key: number]: IDecoratorDetails;
    }
}
declare module "_102027_/l2/validateLit" {
    export function validateTagName(modelTS: mls.editor.IModelTS): boolean;
    export function validateRender(modelTS: mls.editor.IModelTS): boolean;
}
declare module "_102027_/l2/codeLensLit" {
    export function setCodeLens(model1: mls.editor.IModelTS): void;
}
declare module "_102027_/l2/libCompileStyle" {
    export function compileStyleUsingStorFile(shortName: string, project: number, folder: string, theme?: string): Promise<string>;
    export function compileStyleUsingMFile(modelStyle: mls.editor.IModelStyle, theme?: string): Promise<string>;
    export function compileStyleUsingSourceString(sourceLess: string, tokens: string, theme?: string): Promise<string>;
    export function removeTokensFromSource(src: string): string;
    export function removeCommentLines(text: string): string;
    export function isCommentLine(line: string): boolean;
    export interface IDesignSystemTokens {
        description: string;
        themeName: string;
        color: Record<string, string>;
        global: Record<string, string>;
        typography: Record<string, string>;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
}
declare module "_102027_/l2/processCssLit" {
    export function injectStyle(modelTS: mls.editor.IModelTS, theme: string, enhancementName: string): Promise<void>;
    export function injectStyleAction(sourceJS: string, sourceTS: string, sourceLess: string, sourceTokens: string, theme: string, enhancementName: string): Promise<string>;
    export function injectStyleWithoutShadowRoot(modelTS: mls.editor.IModelTS, theme: string, enhancementName: string): Promise<void>;
    export function getCssWithoutTag(css: string, tag: string): string;
}
declare module "_102032_/l2/enhancementLandingPage" {
    export const requires: mls.l2.enhancement.IRequire[];
    export const getDefaultHtmlExamplePreview: (modelTS: mls.editor.IModelTS) => string;
    export const getDesignDetails: (modelTS: mls.editor.IModelTS) => Promise<mls.l2.enhancement.IDesignDetailsReturn>;
    export const onAfterChange: (modelTS: mls.editor.IModelTS) => Promise<void>;
    export const onAfterCompile: (modelTS: mls.editor.IModelTS) => Promise<void>;
    export const onAfterCompileAction: (sourceJS: string, sourceTS: string, css?: {
        sourceLess: string;
        sourceTokens: string;
    }) => Promise<string>;
}
declare module "_102032_/l2/libCompileLandingPage" {
    export function buildLandingPageByStor(stor: mls.stor.IFileInfo, language: ILanguage | undefined, theme?: string): Promise<string>;
    interface ILanguage {
        language: string;
        name: string;
        path: string;
    }
}
declare module "_102027_/l2/pluginBaseIndex" {
    export abstract class PluginBaseIndex {
        abstract getMenus(): mls.plugin.MenuAction[];
        abstract getHooks(): mls.plugin.HookAction[];
        abstract getServices(): mls.plugin.ServiceAction[];
    }
    const _default: "disabled";
    export default _default;
}
declare module "_102032_/l2/pluginCollabCoreIndex" {
    import { PluginBaseIndex } from "_102027_/l2/pluginBaseIndex";
    export class PluginCollabCoreIndex extends PluginBaseIndex {
        getMenus(): mls.plugin.MenuAction[];
        getHooks(): mls.plugin.HookAction[];
        getServices(): mls.plugin.ServiceAction[];
    }
    const _default_1: PluginCollabCoreIndex;
    export default _default_1;
}
declare module "_102027_/l2/collabState" {
    /**
     * Returns the value for a given state key.
     * @param key State key in dot notation.
     * @returns The value stored at the specified key, or undefined if not set.
     */
    export function getState(key: string): any;
    /**
     * Updates the value for a given state key.
     * @param key State key in dot notation.
     * @param value Value to be stored.
     * @param systemChange Optional. If true, marks as a system-initiated change.
     */
    export function setState(key: string, value: any, systemChange?: boolean): void;
    /**
     * Subscribes a component to one or more state keys.
     * @param keyOrKeys - The state key or keys. Example: 'name/0;ui.name'.
     * Use a key starting with '*' (e.g. '*myKey;ui.xxx') to ensure only one active subscription with that key.
     * @param component - The subscribing component or callback function.
     */
    export function subscribe(keyOrKeys: string | string[], component: Object): void;
    /**
     * Unsubscribe a component from a state key or keys.
     * @param keyOrKeys - The state key or keys.
     * @param component - The unsubscribing component.
     */
    export function unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
    /**
     * Notify subscribed components about a state change.
     * @param key - The state key that changed.
     */
    export function notify(key: string): void;
    /**
     * Initializes a nested property in the global state object if it doesn't already exist.
     * If the property exists, it retains its current value without being overwritten.
     *
     * @param {string} path - The dot-separated path specifying the property to initialize (e.g., "globalState.users").
     * @param {*} value - The value to set if the property at the given path does not exist.
     */
    export function initState(path: string, value: string | Object | Array<unknown>): void;
    export interface GlobalState {
        [key: string]: any;
    }
    export const globalState: {
        _ica: GlobalState;
        globalStateManagment: CollabState;
        globalVariation: number;
    };
    export interface CollabState {
        getState(key: string): any;
        setState(key: string, value: any, systemChange?: boolean): void;
        getHistory(): Array<{
            timestamp: number;
            system: boolean;
            key: string;
            value: any;
        }>;
        clearHistory(): void;
        subscribe(keyOrKeys: string | string[], component: Object): void;
        unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
        notify(key: string): void;
    }
    export function getCollabStateInstance(): CollabState;
}
declare module "_102027_/l2/collabLitElement" {
    import { LitElement } from 'lit';
    /**
     * Class extending LitElement with CollabState functionality.
     */
    export class CollabLitElement extends LitElement {
        globalVariation: number;
        createRenderRoot(): this;
        protected updated(changedProperties: Map<string | number | symbol, unknown>): void;
        getMessageKey(messages: any): string;
        loadStyle(css: string): void;
    }
    export function getMessageKey(messages: any): string;
    export interface IScenaryDetails {
        description: string;
        html: HTMLElement;
    }
}
declare module "_102027_/l2/libStor" {
    export function createStorFile(req: IReqCreateStorFile, needCreateModel: boolean, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.stor.IFileInfo>;
    export function createAllFiles(req: IReqCreateAllFiles, needCreateModel?: boolean, awaitCompile?: boolean): Promise<IRetAllFiles>;
    export function deleteFile(storFile: mls.stor.IFileInfo): Promise<void>;
    export function deleteAllFiles(storFile: mls.stor.IFileInfo): Promise<void>;
    export function renameFile(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, needCompile?: boolean): Promise<mls.stor.IFileInfo>;
    export function renameAllFiles(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, needCompile?: boolean): Promise<IRetAllFiles>;
    export function cloneFile(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string): Promise<mls.stor.IFileInfo>;
    export function cloneAllFiles(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string): Promise<IRetAllFiles>;
    export function undoFile(storFile: mls.stor.IFileInfo, removeProject?: boolean): Promise<void>;
    export function undoAllFiles(storFile: mls.stor.IFileInfo): Promise<void>;
    export function replaceTripleslashAndTag(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, src: string): string;
    export interface IReqCreateAllFiles {
        shortName: string;
        project: number;
        folder: string;
        enhancement: string;
        level: number;
        tsSource?: string;
        htmlSource?: string;
        lessSource?: string;
        testSource?: string;
        defsSource?: string;
    }
    export interface IReqCreateStorFile {
        shortName: string;
        project: number;
        folder: string;
        level: number;
        source: string;
        extension: string;
        status?: mls.stor.IFileInfoStatus;
        fileInfo?: {
            originalFolder: string;
            originalProject: number;
            originalShortName: string;
        };
    }
    export interface IRetAllFiles {
        ts?: mls.stor.IFileInfo | undefined | Error;
        html?: mls.stor.IFileInfo | undefined | Error;
        less?: mls.stor.IFileInfo | undefined | Error;
        def?: mls.stor.IFileInfo | undefined | Error;
        test?: mls.stor.IFileInfo | undefined | Error;
    }
}
declare module "_102032_/l2/pluginGenerateDist" {
    import { TemplateResult } from 'lit';
    import { CollabLitElement } from "_102027_/l2/collabLitElement";
    export class PluginGenerateDist extends CollabLitElement {
        private myState;
        private msg;
        private publishModeOptions;
        completed: number[];
        current: number;
        mode: string;
        newVersion: string;
        modeLang: string;
        folders: {
            ori: string;
            dest: string;
        };
        languages: ILanguage[];
        pages: mls.stor.IFileInfo[];
        useRobots: boolean;
        useSiteMap: boolean;
        inPublish: boolean;
        clickedPublish: boolean;
        logs: string[];
        logBox: HTMLElement | undefined;
        txtRobots: HTMLTextAreaElement | undefined;
        iptRobots: HTMLInputElement | undefined;
        iptSitemap: HTMLInputElement | undefined;
        iptBaseSitemap: HTMLInputElement | undefined;
        firstUpdated(): void;
        updated(changedProperties: Map<string | number | symbol, unknown>): Promise<void>;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderWizard(): any;
        renderScenary(): any;
        renderScenary1(): any;
        renderLang(): any;
        renderScenary2(): any;
        renderScenary3(): any;
        private init;
        private getLanguages;
        private getPages;
        private getAssets;
        private next;
        private isValid1;
        private isValid2;
        private startPublish;
        private fineshedPublish;
        private modeVersion;
        private modeHash;
        private publishMyPages;
        private publishPage;
        private createVersionFile;
        private createRobotsFile;
        private createSitemapFile;
        private publishMyAssets;
        private publishAssets;
        private updateVariable;
        private getVariableByProject;
        private addLog;
        private getLocalDateTime;
        private waitRender;
    }
    interface ILanguage {
        language: string;
        name: string;
        path: string;
    }
    export const pluginData: mls.plugin.IPluginData;
}
declare module "_102027_/l2/previewBase" {
    export abstract class PreviewModeBase {
        protected level: string | undefined;
        protected iFrame: HTMLIFrameElement | undefined;
        protected isService: boolean;
        protected storFile: mls.stor.IFileInfo | undefined;
        constructor(_iFrame: HTMLIFrameElement, _level: string, _isService: boolean, _storFile: mls.stor.IFileInfo);
        abstract init(): Promise<void>;
    }
}
declare module "_102032_/l2/previewModeLandingPage" {
    import { PreviewModeBase } from "_102027_/l2/previewBase";
    export class PreviewModeLandingPage extends PreviewModeBase {
        init(): Promise<void>;
        private configIframe;
    }
}
declare module "_102032_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102027_/l2/aiAgentBase" {
    import { TemplateResult } from 'lit';
    /**
     * Agent Architecture Overview
     *
     * The platform supports two agent models. The developer must choose
     * **one model per agent**, based on responsibility and complexity.
     *
     * 1) IAgent (procedural model)
     *    - The agent participates in the execution lifecycle.
     *    - It may orchestrate steps, call tools, and trigger side effects.
     *    - Responsibility: **who executes**.
     *    - Use this when flexibility and custom flow control are required.
     *
     * 2) IAgentAsync (declarative model)
     *    - The agent only describes what should be done and returns data
     *      (e.g. system and human prompts).
     *    - It does NOT execute side effects or control the flow.
     *    - Responsibility: **who describes what must be done**.
     *    - The core is responsible for execution, retries, policies, and limits.
     *    - This model naturally enables **parallel execution**, since agents
     *      are stateless and independent.
     *    - Multiple steps may run concurrently without increasing agent complexity.
     *    - Use this model when simplicity, predictability, testability,
     *      and parallelism are important.
     *
     * Both models coexist without breaking changes.
     * Choose the simplest model that satisfies your use case.
     */
    export type IAgent = IAgentMeta & IAgentLifecycle & IAgentLifecycleSync;
    export type IAgentAsync = IAgentMeta & IAgentLifecycle & IAgentLifecycleHooks;
    export type IAgentMeta = {
        visibility: 'public' | 'private';
        agentName: string;
        agentProject?: number;
        agentFolder?: string;
        scope?: string[];
        avatar_url?: string;
        agentDescription: string;
    };
    export type IAgentLifecycle = {
        beforeClarification?(context: mls.msg.ExecutionContext, stepId: number, readOnly: boolean): Promise<HTMLDivElement | null>;
        afterClarification?(context: mls.msg.ExecutionContext, stepId: number, data: object): Promise<void>;
        afterTool?(context: mls.msg.ExecutionContext, stepId: number): Promise<void>;
        installBot?(context: mls.msg.ExecutionContext): Promise<boolean>;
        beforeBot?(context: mls.msg.ExecutionContext, msg: string, toolsBeforeSendMessage: mls.bots.ToolsBeforeSendMessage[]): Promise<Record<string, any>>;
        afterBot?(context: mls.msg.ExecutionContext, output: mls.msg.BotOutput): Promise<string>;
        replayForSupport?(task: mls.msg.ExecutionContext, payload: mls.msg.AIPayload[]): Promise<void>;
        getFeedBack?(task: mls.msg.TaskData): Promise<TemplateResult>;
    };
    export type IAgentLifecycleSync = {
        beforePrompt(context: mls.msg.ExecutionContext): Promise<void>;
        afterPrompt(context: mls.msg.ExecutionContext): Promise<void>;
    };
    /**
     * Declarative agent lifecycle hooks.
     *
     * These hooks describe what should happen at each entry point
     * without executing side effects (no tool calls, no I/O, no UI).
     *
     * The core orchestrator is responsible for executing the returned intents.
     * Async agents must implement at least one of these entry points.
     */
    export type IAgentLifecycleHooks = {
        /**
         * Called when the agent is invoked with an explicit user prompt
         * in the context of a file (editor, UI, etc).
         *
         * This starts a new task and returns declarative intents
         * describing the next steps to execute.
         */
        beforePromptAtomic?(agent: IAgentMeta, context: mls.msg.ExecutionContext, file: mls.stor.IFileInfo, userPrompt: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called when the agent is invoked without a free-form user prompt.
         *
         * The user may optionally provide a command or parameters as part of the
         * agent invocation (e.g. "@@agentFix", "@@agentFix security").
         *
         * In this mode, the agent does not receive an explicit descriptive prompt.
         * Instead, the system infers the initial intent based on:
         * - the agent name
         * - optional command or parameters
         * - the current execution context
         *
         * This hook is responsible for creating a new task and returning the
         * initial orchestration intents.
         */
        beforePromptImplicit?(agent: IAgentMeta, context: mls.msg.ExecutionContext, userPrompt: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called when the agent is executed as part of an existing task,
         * following a previous step.
         *
         * The agent should read the current task state from the context
         * and return intents describing how the task should continue.
         *
         * Example:
         *   step1 -> agentFix
         *   step2 -> agentFix2 (reads data produced by agentFix)
         */
        beforePromptStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called after a step has completed, allowing the agent to
         * react declaratively to the step result and append new intents.
         */
        afterPromptStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called after a step user call to answer clarification allowing the agent to
         * react declaratively to the clarification result and append new intents.
         */
        beforeClarificationStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIClarificationStep, hookSequential: number, json: any): Promise<HTMLElement>;
    };
    export interface ITool {
        toolName: string;
        tool_url: string | undefined;
        description: string;
        argsSchema: Record<string, any>;
        execute(args: Record<string, any>): Promise<any>;
    }
    export const svg_tool = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 512 512\"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d=\"M176 88l0 40 160 0 0-40c0-4.4-3.6-8-8-8L184 80c-4.4 0-8 3.6-8 8zm-48 40l0-40c0-30.9 25.1-56 56-56l144 0c30.9 0 56 25.1 56 56l0 40 28.1 0c12.7 0 24.9 5.1 33.9 14.1l51.9 51.9c9 9 14.1 21.2 14.1 33.9l0 92.1-128 0 0-32c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 32-128 0 0-32c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 32L0 320l0-92.1c0-12.7 5.1-24.9 14.1-33.9l51.9-51.9c9-9 21.2-14.1 33.9-14.1l28.1 0zM0 416l0-64 128 0c0 17.7 14.3 32 32 32s32-14.3 32-32l128 0c0 17.7 14.3 32 32 32s32-14.3 32-32l128 0 0 64c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64z\"/></svg>";
    export const svg_agent = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 640 512\"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d=\"M320 0c17.7 0 32 14.3 32 32l0 64 120 0c39.8 0 72 32.2 72 72l0 272c0 39.8-32.2 72-72 72l-304 0c-39.8 0-72-32.2-72-72l0-272c0-39.8 32.2-72 72-72l120 0 0-64c0-17.7 14.3-32 32-32zM208 384c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zm96 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zm96 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zM264 256a40 40 0 1 0 -80 0 40 40 0 1 0 80 0zm152 40a40 40 0 1 0 0-80 40 40 0 1 0 0 80zM48 224l16 0 0 192-16 0c-26.5 0-48-21.5-48-48l0-96c0-26.5 21.5-48 48-48zm544 0c26.5 0 48 21.5 48 48l0 96c0 26.5-21.5 48-48 48l-16 0 0-192 16 0z\"/></svg>";
    /**
     * Agent middleware is a function that receives an IAgent and returns
     * a new IAgent that wraps the original one.
     *
     * Middleware must NOT change the agent contract or business semantics.
     * It should only handle cross-cutting concerns such as logging,
     * metrics, tracing, retries, or safety checks.
     *
     * Middleware should be stateless and rely on the execution context
     * for any per-run data, ensuring it works with singleton or factory-based agents.
     *
     * Usage pattern:
     *   const agent = withLogging(createAgent())
     */
    /**
     * Example
     * Adds logging around agent execution lifecycle.
     *
     * This middleware logs when the agent starts and finishes processing
     * a prompt without requiring any changes to the agent implementation.
     *
     * It wraps existing hooks safely and preserves optional capabilities.
     */
    export function withLogging(agent: IAgent): IAgent;
}
declare module "_102027_/l2/aiAgentHelper" {
    /**
     * Helper function to collect all steps from a task in a flat array
     */
    export const getAllSteps: (firstStep: mls.msg.AIPayload[] | undefined) => mls.msg.AIPayload[];
    export const getAgentStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIPayload | null;
    export const getAllAgentStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIPayload[] | null;
    export const getAgentsStepByAgentName: (task: mls.msg.TaskData, agentName: string, status?: mls.msg.AIStepStatus) => mls.msg.AIPayload[];
    export const getStepById: (task: mls.msg.TaskData, stepId: number) => mls.msg.AIPayload | null;
    export const getNextPendentStep: (task: mls.msg.TaskData) => mls.msg.AIPayload | null;
    export const getNextResultStep: (task: mls.msg.TaskData) => mls.msg.AIResultStep | null;
    export const getNextClarificationStep: (task: mls.msg.TaskData) => mls.msg.AIClarificationStep | null;
    export const getNextPendingStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIAgentStep | null;
    export const getNextFlexiblePendingStep: (task: mls.msg.TaskData) => mls.msg.AIFlexibleResultStep | null;
    export const getNextInProgressStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIAgentStep | null;
    export const getRootAgent: (task: mls.msg.TaskData) => mls.msg.AIAgentStep | null;
    export const getInteractionStepId: (task: mls.msg.TaskData, stepId: number) => number | null;
    export type StatisticsAITask = {
        agents: number;
        tools: number;
        clarification: number;
        result: number;
        flexible: number;
        totalCost: number;
        totalSteps: number;
    };
    export const calculateStepsStatistics: (steps: mls.msg.AIPayload[], removeFirstStep: boolean) => StatisticsAITask;
    export const calculateStepsByFilter: (task: mls.msg.TaskData, filter: Record<string, any>) => number;
    export const getTemporaryContext: (threadId: string, userId: string, prompt: string) => mls.msg.ExecutionContext;
    export function notifyMessageSendChange(context: mls.msg.ExecutionContext): void;
    export function notifyTaskChange(context: mls.msg.ExecutionContext, oldContextCreateAt?: string): void;
    export function notifyTaskCompleted(context: mls.msg.ExecutionContext, result?: string): void;
    export function notifyThreadChange(thread: mls.msg.Thread): void;
    export function notifyMessageChange(message: mls.msg.Message): void;
    export function notifyThreadCreate(thread: mls.msg.Thread): void;
    export function dispatchDetailsTaskClose(taskId: string): void;
    export function getTotalCost(task: mls.msg.TaskData): string;
    export function appendLongTermMemory(context: mls.msg.ExecutionContext, longTermMemory: Record<string, string>): Promise<mls.msg.TaskData>;
    export function getNextStepIdAvaliable(task: mls.msg.TaskData): number;
}
declare module "_102027_/l2/aiAgentOrchestration" {
    import { IAgent, IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function executeBeforePrompt(agent: IAgent | IAgentAsync, context: mls.msg.ExecutionContext): Promise<void>;
    export function continuePoolingTask(context: mls.msg.ExecutionContext): Promise<void>;
    export function pauseOrContinueTask(reason: string, context: mls.msg.ExecutionContext, action: "paused" | "continue"): Promise<void>;
    export function executeTool(toolName: string, args: string): Promise<IExecuteToolReturn>;
    export function finishClarification(agent: IAgent | IAgentAsync, stepId: number, parentStepId: number, intents: mls.msg.AgentIntent[], context: mls.msg.ExecutionContext, value: string, action: "continue" | "cancel"): Promise<void>;
    export function prepareClarificationElement(agent: IAgent | IAgentAsync, context: mls.msg.ExecutionContext, stepId: number, parentStepId: number, intents: mls.msg.AgentIntent[], clarification: ClarificationValue | Object | string): Promise<HTMLElement>;
    export function getClarificationElement(context: mls.msg.ExecutionContext): Promise<HTMLElement>;
    export function getAgentContext(taskId: string): Promise<{
        context: mls.msg.ExecutionContext;
        interaction: mls.msg.AIAgentStep;
        step: mls.msg.AIPayload;
    }>;
    export function loadAgent(agentName: string): Promise<IAgent | IAgentAsync | undefined>;
    export function loadTool(toolName: string): Promise<any | undefined>;
    type InstanceMode = 'agent' | 'tool';
    /**
     * agentName, ex: 'agentXX1' or '_100554_/l2/agents/agentXX1'
     */
    export function getInstanceByName(nameOrPath: string, mode: InstanceMode): Promise<IAgent | IAgentAsync | undefined>;
    export interface IExecuteToolReturn {
        status: boolean;
        error: string;
        result: any;
    }
    export interface ClarificationValue {
        taskId: string;
        stepId: number;
        title: string;
        userLanguage: string;
        questions: ClarificationQuestions;
        legends: string[];
    }
    export interface ClarificationQuestions {
        [key: string]: Question;
    }
    export interface Question {
        type: 'open' | 'select' | 'boolean' | 'MoSCoW' | 'range';
        question: string;
        answer?: string | boolean;
        options?: QuestionOption[];
    }
    export interface QuestionOption {
        id: string;
        label: string;
    }
}
declare module "_102032_/l2/agents/agentTextExtractor" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export type Output = {
        type: "flexible";
        result: {
            fileReference: string;
            items: TranslationExtractItem[];
        };
    };
    export interface TranslationExtractItem {
        id: string;
        text: string;
        tag: string;
        path: string;
        context: string;
        translatable: boolean;
    }
}
declare module "_102032_/l2/agents/agentTextTranslation" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export type Output = {
        type: "flexible";
        result: TranslationItem[];
    };
    export interface TranslationItem {
        id: string;
        tag: string;
        original: string;
        translation: string;
    }
}
declare module "_102032_/l2/agents/agentTranslationApplier" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export type Output = {
        type: "flexible";
        result: string;
    };
}
declare module "_102027_/l2/stateLitElement" {
    import { CollabLitElement } from "_102027_/l2/collabLitElement";
    import { PropertyValueMap } from 'lit';
    /**
     * Base class for all components that need to interact with the shared state.
     */
    export abstract class StateLitElement extends CollabLitElement {
        stateKeys: Map<string, boolean>;
        updateStateKeys(attributeName: string, paths: string[]): void;
        private subscribeToState;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        firstUpdated(_changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        updated(_changedProps: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        /**
         * Handle state changes from IcaState.
         * @param key - The state key that changed, ex: 'users[0].name'
         * @param value - The new value of the state.
         */
        handleIcaStateChange(key: string, value: any): void;
        connectMonitoring(): void;
    }
}
declare module "_102032_/l2/plugins/pluginTranslate" {
    import { StateLitElement } from "_102027_/l2/stateLitElement";
    export class PluginTranslate100554 extends StateLitElement {
        private msg;
        project: number;
        originFolder: string;
        targetFolder: string;
        originLanguage: string;
        targetLanguage: string;
        excludeFiles: string;
        pages: string;
        private generatePrompt;
        render(): any;
    }
    export const pluginData: mls.plugin.IPluginData;
}
