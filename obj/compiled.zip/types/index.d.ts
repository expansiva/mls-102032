declare module "_102032_/l2/collabLandingPage.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102032_/l2/collabLandingPage" {
    /**
     * Class extending LitElement with CollabState functionality.
     */
    export class CollabLandingPage extends HTMLElement {
        createRenderRoot(): this;
        getMessageKey(messages: any): string;
        loadStyle(css: string): void;
    }
    export function getMessageKey(messages: any): string;
}
declare module "_102032_/l2/designSystem.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102032_/l2/designSystem" {
    import { IDesignSystemTokens } from '_100554_/l2/designSystemBase';
    export const tokens: IDesignSystemTokens[];
}
declare module "_102032_/l2/enhancementLandingPage.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102032_/l2/enhancementLandingPage" {
    export const requires: mls.l2.enhancement.IRequire[];
    export const getDefaultHtmlExamplePreview: (modelTS: mls.editor.IModelTS) => string;
    export const getDesignDetails: (modelTS: mls.editor.IModelTS) => Promise<mls.l2.enhancement.IDesignDetailsReturn>;
    export const onAfterChange: (modelTS: mls.editor.IModelTS) => Promise<void>;
    export const onAfterCompile: (modelTS: mls.editor.IModelTS) => Promise<void>;
    export const onAfterCompileAction: (sourceJS: string, sourceTS: string, css?: {
        sourceLess: string;
        sourceTokens: string;
    }) => Promise<string>;
}
declare module "_102032_/l2/pluginCollabCoreIndex.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102032_/l2/pluginCollabCoreIndex" {
    import { PluginBaseIndex } from '_100554_/l2/pluginBaseIndex';
    export class PluginCollabCoreIndex extends PluginBaseIndex {
        getMenus(): mls.plugin.MenuAction[];
        getHooks(): mls.plugin.HookAction[];
        getServices(): mls.plugin.ServiceAction[];
    }
    const _default: PluginCollabCoreIndex;
    export default _default;
}
declare module "_102032_/l2/project.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102032_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102032_/l2/agents/agentTextExtractor.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102032_/l2/agents/agentTextExtractor" {
    import { IAgentAsync } from '_100554_/l2/aiAgentBase';
    export function createAgent(): IAgentAsync;
    export type Output = {
        type: "flexible";
        result: {
            fileReference: string;
            items: TranslationExtractItem[];
        };
    };
    export interface TranslationExtractItem {
        id: string;
        text: string;
        tag: string;
        path: string;
        context: string;
        translatable: boolean;
    }
}
declare module "_102032_/l2/agents/agentTextTranslation.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102032_/l2/agents/agentTextTranslation" {
    import { IAgentAsync } from '_100554_/l2/aiAgentBase';
    export function createAgent(): IAgentAsync;
    export type Output = {
        type: "flexible";
        result: TranslationItem[];
    };
    export interface TranslationItem {
        id: string;
        tag: string;
        original: string;
        translation: string;
    }
}
declare module "_102032_/l2/agents/agentTranslationApplier.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102032_/l2/agents/agentTranslationApplier" {
    import { IAgentAsync } from '_100554_/l2/aiAgentBase';
    export function createAgent(): IAgentAsync;
    export type Output = {
        type: "flexible";
        result: string;
    };
}
declare module "_102032_/l2/plugins/pluginTranslate.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102032_/l2/plugins/pluginTranslate" {
    import { StateLitElement } from '_100554_/l2/stateLitElement';
    export class PluginTranslate100554 extends StateLitElement {
        private msg;
        project: number;
        originFolder: string;
        targetFolder: string;
        originLanguage: string;
        targetLanguage: string;
        excludeFiles: string;
        pages: string;
        private generatePrompt;
        render(): any;
    }
    export const pluginData: mls.plugin.IPluginData;
}
