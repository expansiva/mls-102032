/// <mls fileReference="_102032_/l2/pluginGenerateDist.test.ts" enhancement="_blank"/>
export const integrations = [];
export const tests = [];
