/// <mls fileReference="_102032_/l2/plugins/pluginTranslate.ts" enhancement="_102027_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, svg } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
/// **collab_i18n_start**
const message_pt = {
    title: 'Configuração do Tradutor',
    project: 'Projeto',
    originFolder: 'Pasta de Origem',
    targetFolder: 'Pasta de Destino',
    originLanguage: 'Idioma de Origem',
    targetLanguage: 'Idioma de Destino',
    excludeFiles: 'Arquivos a Excluir (separados por vírgula)',
    pages: 'Somente Páginas (separadas por vírgula)',
    generatedPrompt: 'Prompt Gerado',
    copy: 'Copiar'
};
const message_en = {
    title: 'Translator Configuration',
    project: 'Project',
    originFolder: 'Origin Folder',
    targetFolder: 'Target Folder',
    originLanguage: 'Origin Language',
    targetLanguage: 'Target Language',
    excludeFiles: 'Exclude Files (comma separated)',
    pages: 'Only Pages (comma separated)',
    generatedPrompt: 'Generated Prompt',
    copy: 'Copy'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let PluginTranslate100554 = class PluginTranslate100554 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugins--plugin-translate-102032 {
  display: block;
  font-family: var(--font-family-primary);
}
plugins--plugin-translate-102032 .container {
  padding: var(--space-24);
  background: var(--bg-primary-color);
  border: 1px solid var(--grey-color-dark);
  border-radius: 6px;
  max-width: 600px;
}
plugins--plugin-translate-102032 label {
  display: block;
  margin-top: var(--space-16);
  font-size: var(--font-size-12);
  color: var(--text-primary-color);
}
plugins--plugin-translate-102032 input {
  width: 100%;
  padding: var(--space-8);
  margin-top: var(--space-8);
  border: 1px solid var(--grey-color-dark);
  border-radius: 4px;
}
plugins--plugin-translate-102032 pre {
  margin-top: var(--space-24);
  padding: var(--space-16);
  background: var(--grey-color-light);
  border-radius: 4px;
  font-size: var(--font-size-12);
  overflow: auto;
}
plugins--plugin-translate-102032 button {
  margin-top: var(--space-16);
  padding: var(--space-8) var(--space-16);
  background: var(--active-color);
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}
`);
        this.msg = messages['en'];
        this.project = 102031;
        this.originFolder = 'www/en';
        this.targetFolder = 'www/pt';
        this.originLanguage = 'en';
        this.targetLanguage = 'pt';
        this.excludeFiles = '';
        this.pages = '';
    }
    generatePrompt() {
        const config = {
            targetLanguage: this.targetLanguage,
            targetFolder: this.targetFolder,
            originFolder: this.originFolder,
            originLanguage: this.originLanguage,
            project: Number(this.project)
        };
        if (this.pages.trim()) {
            config.pages = this.pages.split(',').map(v => v.trim());
        }
        else if (this.excludeFiles.trim()) {
            config.excludeFiles = this.excludeFiles.split(',').map(v => v.trim());
        }
        return `@@agentTextExtractor ${JSON.stringify(config)}`;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const prompt = this.generatePrompt();
        return html `

        <div class="container">

            <h3>${this.msg.title}</h3>

            <label>${this.msg.project}</label>
            <input type="number"
                .value=${this.project}
                @input=${(e) => this.project = e.target.value}>

            <label>${this.msg.originFolder}</label>
            <input
                .value=${this.originFolder}
                @input=${(e) => this.originFolder = e.target.value}>

            <label>${this.msg.targetFolder}</label>
            <input
                .value=${this.targetFolder}
                @input=${(e) => this.targetFolder = e.target.value}>

            <label>${this.msg.originLanguage}</label>
            <input
                .value=${this.originLanguage}
                @input=${(e) => this.originLanguage = e.target.value}>

            <label>${this.msg.targetLanguage}</label>
            <input
                .value=${this.targetLanguage}
                @input=${(e) => this.targetLanguage = e.target.value}>

            <label>${this.msg.excludeFiles}</label>
            <input
                .value=${this.excludeFiles}
                @input=${(e) => this.excludeFiles = e.target.value}>

            <label>${this.msg.pages}</label>
            <input
                .value=${this.pages}
                @input=${(e) => this.pages = e.target.value}>

            <h4>${this.msg.generatedPrompt}</h4>

            <pre>${prompt}</pre>

            <button
                @click=${() => navigator.clipboard.writeText(prompt)}>
                ${this.msg.copy}
            </button>

        </div>

        `;
    }
};
__decorate([
    state()
], PluginTranslate100554.prototype, "project", void 0);
__decorate([
    state()
], PluginTranslate100554.prototype, "originFolder", void 0);
__decorate([
    state()
], PluginTranslate100554.prototype, "targetFolder", void 0);
__decorate([
    state()
], PluginTranslate100554.prototype, "originLanguage", void 0);
__decorate([
    state()
], PluginTranslate100554.prototype, "targetLanguage", void 0);
__decorate([
    state()
], PluginTranslate100554.prototype, "excludeFiles", void 0);
__decorate([
    state()
], PluginTranslate100554.prototype, "pages", void 0);
PluginTranslate100554 = __decorate([
    customElement('plugins--plugin-translate-102032')
], PluginTranslate100554);
export { PluginTranslate100554 };
export const pluginData = {
    title: "Translate",
    getSvg() {
        return svg `
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 110.94 122.88"><title>lookup</title><path fill="currentColor" d="M19.26,40.53a2.74,2.74,0,0,1-2.59-2.82,2.69,2.69,0,0,1,2.59-2.82H63.41A2.72,2.72,0,0,1,66,37.71a2.68,2.68,0,0,1-2.58,2.82ZM79.41,66a24.82,24.82,0,0,1,20.78,38.41l10.75,11.71-7.42,6.77-10.36-11.4A24.82,24.82,0,1,1,79.41,66Zm13.2,11.62a18.66,18.66,0,1,0,5.47,13.2,18.66,18.66,0,0,0-5.47-13.2Zm-73.32-22a2.73,2.73,0,0,1-2.58-2.82A2.68,2.68,0,0,1,19.29,50H41.37A2.74,2.74,0,0,1,44,52.84a2.68,2.68,0,0,1-2.58,2.82ZM82.76,17.14H92a6.64,6.64,0,0,1,6.61,6.61V55.18c-.2,2.07-5.27,2.1-5.7,0V23.75a.92.92,0,0,0-.94-.94H82.73V55.18c-.49,1.88-4.72,2.16-5.67,0V6.61a.92.92,0,0,0-.94-.94H6.58a1,1,0,0,0-.68.27,1,1,0,0,0-.26.67V85.18a1,1,0,0,0,.26.67,1,1,0,0,0,.68.27H43.36c2.86.29,3,5.23,0,5.67H21.5v10.53a.92.92,0,0,0,.94.94H43.36c2.07.23,2.74,4.94,0,5.67H22.48a6.62,6.62,0,0,1-6.61-6.61V91.79H6.61a6.49,6.49,0,0,1-4.66-2A6.56,6.56,0,0,1,0,85.18V6.61A6.49,6.49,0,0,1,2,2,6.55,6.55,0,0,1,6.61,0H76.16a6.51,6.51,0,0,1,4.66,2,6.54,6.54,0,0,1,1.94,4.66V17.14ZM19.26,25.4a2.74,2.74,0,0,1-2.59-2.82,2.69,2.69,0,0,1,2.59-2.82H63.41A2.73,2.73,0,0,1,66,22.58a2.69,2.69,0,0,1-2.58,2.82Z"/></svg>
    `;
    }
};
