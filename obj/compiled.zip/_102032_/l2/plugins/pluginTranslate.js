/// <mls fileReference="_102032_/l2/plugins/pluginTranslate.ts" enhancement="_102027_enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_100554_/l2/stateLitElement.js';
/// **collab_i18n_start**
const message_pt = {
    title: 'Configuração do Tradutor',
    project: 'Projeto',
    originFolder: 'Pasta de Origem',
    targetFolder: 'Pasta de Destino',
    originLanguage: 'Idioma de Origem',
    targetLanguage: 'Idioma de Destino',
    excludeFiles: 'Arquivos a Excluir (separados por vírgula)',
    pages: 'Somente Páginas (separadas por vírgula)',
    generatedPrompt: 'Prompt Gerado',
    copy: 'Copiar'
};
const message_en = {
    title: 'Translator Configuration',
    project: 'Project',
    originFolder: 'Origin Folder',
    targetFolder: 'Target Folder',
    originLanguage: 'Origin Language',
    targetLanguage: 'Target Language',
    excludeFiles: 'Exclude Files (comma separated)',
    pages: 'Only Pages (comma separated)',
    generatedPrompt: 'Generated Prompt',
    copy: 'Copy'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let PluginTranslate100554 = class PluginTranslate100554 extends StateLitElement {
    constructor() {
        super(...arguments);
        this.msg = messages['en'];
        this.project = 102031;
        this.originFolder = 'www/en';
        this.targetFolder = 'www/pt';
        this.originLanguage = 'en';
        this.targetLanguage = 'pt';
        this.excludeFiles = '';
        this.pages = '';
    }
    generatePrompt() {
        const config = {
            targetLanguage: this.targetLanguage,
            targetFolder: this.targetFolder,
            originFolder: this.originFolder,
            originLanguage: this.originLanguage,
            project: Number(this.project)
        };
        if (this.pages.trim()) {
            config.pages = this.pages.split(',').map(v => v.trim());
        }
        else if (this.excludeFiles.trim()) {
            config.excludeFiles = this.excludeFiles.split(',').map(v => v.trim());
        }
        return `@@agentTextExtractor ${JSON.stringify(config)}`;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const prompt = this.generatePrompt();
        return html `

        <div class="container">

            <h3>${this.msg.title}</h3>

            <label>${this.msg.project}</label>
            <input type="number"
                .value=${this.project}
                @input=${(e) => this.project = e.target.value}>

            <label>${this.msg.originFolder}</label>
            <input
                .value=${this.originFolder}
                @input=${(e) => this.originFolder = e.target.value}>

            <label>${this.msg.targetFolder}</label>
            <input
                .value=${this.targetFolder}
                @input=${(e) => this.targetFolder = e.target.value}>

            <label>${this.msg.originLanguage}</label>
            <input
                .value=${this.originLanguage}
                @input=${(e) => this.originLanguage = e.target.value}>

            <label>${this.msg.targetLanguage}</label>
            <input
                .value=${this.targetLanguage}
                @input=${(e) => this.targetLanguage = e.target.value}>

            <label>${this.msg.excludeFiles}</label>
            <input
                .value=${this.excludeFiles}
                @input=${(e) => this.excludeFiles = e.target.value}>

            <label>${this.msg.pages}</label>
            <input
                .value=${this.pages}
                @input=${(e) => this.pages = e.target.value}>

            <h4>${this.msg.generatedPrompt}</h4>

            <pre>${prompt}</pre>

            <button
                @click=${() => navigator.clipboard.writeText(prompt)}>
                ${this.msg.copy}
            </button>

        </div>

        `;
    }
};
__decorate([
    state()
], PluginTranslate100554.prototype, "project", void 0);
__decorate([
    state()
], PluginTranslate100554.prototype, "originFolder", void 0);
__decorate([
    state()
], PluginTranslate100554.prototype, "targetFolder", void 0);
__decorate([
    state()
], PluginTranslate100554.prototype, "originLanguage", void 0);
__decorate([
    state()
], PluginTranslate100554.prototype, "targetLanguage", void 0);
__decorate([
    state()
], PluginTranslate100554.prototype, "excludeFiles", void 0);
__decorate([
    state()
], PluginTranslate100554.prototype, "pages", void 0);
PluginTranslate100554 = __decorate([
    customElement('plugins--plugin-translate-102032')
], PluginTranslate100554);
export { PluginTranslate100554 };
