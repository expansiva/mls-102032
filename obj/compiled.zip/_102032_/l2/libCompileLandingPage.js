/// <mls fileReference="_102032_/l2/libCompileLandingPage.ts" enhancement="_blank"/>
import { getDependenciesByHtmlFile } from '/_102027_/l2/libCompile.js';
import { getPath, convertFileNameToTag } from '/_102027_/l2/utils.js';
export async function buildLandingPageByStor(stor, language, theme = 'Default') {
    let { project, shortName, folder } = stor;
    const keyHTML = mls.stor.getKeyToFiles(project, 2, shortName, folder, '.html');
    if (!mls.stor.files[keyHTML]) {
        throw new Error(`Not found html page: ${stor.folder ? stor.folder + '/' + stor.shortName : stor.shortName}`);
    }
    const contentHTML = await mls.stor.files[keyHTML].getContent();
    let json = await getDependenciesByHtmlFile(stor, contentHTML, theme, true);
    const js = await buildJs(json, stor);
    const content = await generateHTML(project, json, js, contentHTML);
    return content;
}
async function buildJs(json, stor) {
    await loadEsbuild();
    let allImports = [...new Set(json.importsJs.filter((i) => i.startsWith('/')))];
    const virtualFsPlugin = {
        name: 'virtual-fs',
        setup(build) {
            build.onResolve({ filter: /.*/ }, (args) => {
                if ((args.path.startsWith("/") || args.path.startsWith("./") || args.path.startsWith("../")) &&
                    !args.importer.startsWith("https://")) {
                    const url = new URL(args.path, 'file:' + args.importer);
                    let path = url.pathname;
                    if (!(/_(\d+)_/.test(path))) {
                        const info = getPath(args.importer.replace('/l2/', '').replace('/', ''));
                        if (!info)
                            throw new Error('[virtualFsPlugin] Not found path:' + args.importer.replace('/l2/', '').replace('/', ''));
                        if (!info.project)
                            info.project = mls.actualProject;
                        if (path.indexOf(`_${info.project}_`) < 0) {
                            path = url.pathname.replace('/', `/_${info.project}_`);
                        }
                    }
                    return { path, namespace: 'virtual' };
                }
                return null;
            });
            build.onLoad({ filter: /.*/, namespace: 'virtual' }, async (args) => {
                try {
                    let path = args.path;
                    const res = await fetch(path);
                    if (!res.ok)
                        throw new Error(`Error get ${args.path}`);
                    const text = await res.text();
                    return { contents: text, loader: 'js' };
                }
                catch (e) {
                    console.info('erro:' + args.path);
                    return {
                        contents: '',
                        loader: 'js',
                        warnings: [{
                                text: e.message, notes: [
                                    { text: 'build-error' }
                                ]
                            }]
                    };
                }
            });
        },
    };
    const virtualEntryPath = "virtual-entry.js";
    const virtualEntryContent = allImports.map(path => `import "${path}";`).join("\n");
    const result = await esbuild.build({
        stdin: {
            contents: virtualEntryContent,
            resolveDir: "/",
            sourcefile: virtualEntryPath,
            loader: "js"
        },
        bundle: true,
        minify: true,
        format: "esm",
        sourcemap: false,
        write: false,
        plugins: [virtualFsPlugin]
    });
    return result.outputFiles[0].text;
}
async function getPreviewConfigByProject(project) {
    if (!project)
        return;
    const url = `/_${project}_/l2/project.js`;
    try {
        const modulePrj = await import(url);
        if (!modulePrj || !modulePrj.projectConfig || !modulePrj.projectConfig.masterFrontEnd || !modulePrj.projectConfig.masterFrontEnd.preview)
            return;
        return modulePrj.projectConfig.masterFrontEnd;
    }
    catch (err) {
        console.error('no find project config');
        return;
    }
}
async function generateHTML(project, json, js, contentHTML) {
    const css = await getCss(json);
    const info = await getPreviewConfigByProject(project);
    console.info(info);
    const metas = (info.meta || []).join('\n');
    let html = `
    <html lang="en">


    <head>
        ${info?.title ? `<title>${info.title}</title>` : '<title> Landing Page</title>'}
        ${metas}        
        ${json.importsLinks.map((i) => { return `<link ref="${i.ref}" rel="${i.rel}"/>`; })}
        ${css}
    </head>
    <body>
        ${contentHTML}
        <script type=>
            ${js}
        </script> 
        ${json.importsJs.map((i) => { if (i.startsWith('/')) {
        return '';
    }
    else
        return `<script src="${i}"></script>`; })}
        
    </body> 
    </html>  
    `;
    return html;
}
async function getCss(json) {
    let css = json.tokens || '';
    for await (const js of json.importsJs) {
        if (!js.startsWith('/'))
            continue;
        const path = getPath(js.replace('/', ''));
        if (!path)
            continue;
        const k = mls.stor.getKeyToFile({ ...path, level: 2, extension: '.less' });
        const s = mls.stor.files[k];
        if (!s)
            continue;
        const src = await s.getContent();
        const less = await mls.l2.less.compile(src);
        const tag = convertFileNameToTag(s);
        if (!less)
            continue;
        css = `
            ${css}
            ${less.replace(new RegExp(tag, 'g'), '')}
            `;
    }
    return `<style>${css}</style>`;
}
var esbuild;
async function loadEsbuild() {
    if (mls.esbuild) {
        esbuild = mls.esbuild;
    }
    else if (!mls.esbuildInLoad)
        await initializeEsBuild();
}
async function initializeEsBuild() {
    mls.esbuildInLoad = true;
    const url = 'https://unpkg.com/esbuild-wasm@0.14.54/esm/browser.min.js';
    if (!esbuild) {
        esbuild = await import(url);
        await esbuild.initialize({
            wasmURL: "https://unpkg.com/esbuild-wasm@0.14.54/esbuild.wasm"
        });
        mls.esbuild = esbuild;
        mls.esbuildInLoad = false;
    }
}
