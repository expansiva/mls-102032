/// <mls fileReference="_102032_/l2/pluginGenerateDist.ts" enhancement="_102027_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, svg, unsafeHTML } from 'lit';
import { state, query } from 'lit/decorators.js';
import { CollabLitElement } from '/_102027_/l2/collabLitElement.js';
import { getAllDefs } from '/_102027_/l2/libMindMap.js';
import { createStorFile } from '/_102027_/l2/libStor.js';
import { buildLandingPageByStor } from '/_102032_/l2/libCompileLandingPage.js';
/// **collab_i18n_start**
const message_pt = {
    clickInPublish: "Clique no botão 'publicar' para iniciar a publicação.",
    step1: "Configuração",
    step2: "Selecionar Páginas",
    step3: "Log de Geração",
    continue: "Continuar",
    back: "Voltar",
    publish: "Publicar",
    alertTitle: "⚠️ Atenção",
    alertOnlySelected: "Apenas as páginas selecionadas neste passo serão atualizadas.",
    alertNotSelected: "Páginas não selecionadas não serão atualizadas após a conclusão.",
    alertReview: "Recomendamos revisar cuidadosamente as páginas selecionadas antes de continuar.",
    errorLanguage: "É preciso selecionar pelo menos uma linguagem!",
    errorPage: "É preciso selecionar pelo menos uma página!",
    startPublish: "Iniciando processo de publicação",
    publishCompleted: "Publicação concluída!",
    startingPublishLanguage: "Iniciando publicação da linguagem:",
    compilingPage: "Compilando página:",
    startingSaveDist: "Iniciando salvamento do dist",
    checkingFork: "Verificando fork...",
    addNewBranch: "Criando nova branch...",
    savingFiles: "Salvando arquivos...",
    savingAssets: "Salvando recursos...",
    creatingPullRequest: "Criando pull request...",
    publishFinish: "Finalizar"
};
const message_en = {
    clickInPublish: "Click the 'publish' button to start publishing.",
    step1: "Configuration",
    step2: "Select Pages",
    step3: "Generate Log",
    continue: "Continue",
    back: "Back",
    publish: "Publish",
    alertTitle: "⚠️ Attention",
    alertOnlySelected: "Only selected pages will be updated.",
    alertNotSelected: "Unselected pages will not be updated after completion.",
    alertReview: "We recommend carefully reviewing selected pages before continuing.",
    errorLanguage: "You must select at least one language!",
    errorPage: "You must select at least one page!",
    startPublish: "Starting publish process",
    publishCompleted: "Publish completed!",
    startingPublishLanguage: "Starting publish language:",
    compilingPage: "Compiling page:",
    startingSaveDist: "Starting save dist",
    checkingFork: "Checking fork...",
    addNewBranch: "Creating new branch...",
    savingFiles: "Saving files...",
    savingAssets: "Saving assets...",
    creatingPullRequest: "Creating pull request...",
    publishFinish: "Finish"
};
const messages = {
    'pt': message_pt,
    'en': message_en
};
/// **collab_i18n_end**
export class PluginGenerateDist extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-generate-dist-102032 {
  display: block;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
  color: var(--text-primary-color);
  overflow-y: auto;
}
plugin-generate-dist-102032 .agent-box {
  max-width: 1200px;
  margin: 10px auto;
  padding: 0.3rem;
  border-radius: 18px;
}
plugin-generate-dist-102032 header {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 24px;
  border-bottom: 1px solid #ececec;
  padding-bottom: 12px;
}
plugin-generate-dist-102032 header span {
  font-size: 20px;
  font-weight: 600;
  margin: 0;
}
plugin-generate-dist-102032 header .svg-container {
  width: 22px;
  margin: 4px;
  display: inline-flex;
  fill: var(--text-primary-color);
}
plugin-generate-dist-102032 icon svg {
  width: 22px;
  height: 22px;
  color: var(--text-primary-color);
  fill: var(--text-primary-color);
}
plugin-generate-dist-102032 .steps {
  display: flex;
  justify-content: space-between;
  margin-bottom: 40px;
}
plugin-generate-dist-102032 .step {
  flex: 1;
  text-align: center;
  position: relative;
}
plugin-generate-dist-102032 .step:not(:last-child)::after {
  content: '';
  position: absolute;
  top: 18px;
  right: -50%;
  width: 100%;
  height: 2px;
  background: #e0e0e0;
  z-index: 0;
}
plugin-generate-dist-102032 .circle {
  width: 36px;
  height: 36px;
  border-radius: 50%;
  margin: 0 auto 8px;
  line-height: 36px;
  background: #e0e0e0;
  color: #666;
  font-weight: 500;
  position: relative;
  z-index: 1;
}
plugin-generate-dist-102032 .step.active .circle {
  background: #2563eb;
  color: #fff;
}
plugin-generate-dist-102032 .step.completed .circle {
  background: #16a34a;
  color: #fff;
}
plugin-generate-dist-102032 .step span {
  font-size: 13px;
  color: #777;
}
plugin-generate-dist-102032 .content {
  display: block;
  width: 80%;
  margin: auto auto;
}
plugin-generate-dist-102032 .card {
  border: 1px solid #e5e7eb;
  padding: 20px;
  border-radius: 12px;
  margin-bottom: 20px;
  transition: 0.2s ease;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 0.3rem;
}
plugin-generate-dist-102032 .card:hover {
  border-color: #2563eb;
  color: #2563eb;
}
plugin-generate-dist-102032 .card input {
  margin-right: 10px;
  cursor: pointer;
}
plugin-generate-dist-102032 .grid {
  display: flex;
  gap: 15px;
  flex-wrap: wrap;
}
plugin-generate-dist-102032 .actions {
  margin-top: 30px;
  text-align: right;
}
plugin-generate-dist-102032 button {
  background: #2563eb;
  border: none;
  color: white;
  padding: 12px 20px;
  border-radius: 10px;
  cursor: pointer;
  font-weight: 500;
  transition: 0.2s;
}
plugin-generate-dist-102032 button:hover {
  background: #1d4ed8;
}
plugin-generate-dist-102032 button.secondary {
  background: #e5e7eb;
  color: #333;
  margin-right: 10px;
}
plugin-generate-dist-102032 button.secondary:hover {
  background: #d1d5db;
}
plugin-generate-dist-102032 .log-box {
  background: #0f172a;
  color: #e2e8f0;
  padding: 20px;
  border-radius: 12px;
  font-size: 14px;
  height: 200px;
  overflow-y: auto;
  font-family: monospace;
}
plugin-generate-dist-102032 .log-line {
  margin-bottom: 6px;
}
plugin-generate-dist-102032 .log-success {
  color: #22c55e;
}
plugin-generate-dist-102032 .log-info {
  color: #38bdf8;
}
plugin-generate-dist-102032 .publish-alert {
  background: #fffef0;
  border: 1px solid #fef8ca;
  border-left: 6px solid #f7fb05;
  padding: 24px 28px;
  border-radius: 14px;
  max-width: 750px;
  font-family: 'Inter', sans-serif;
  animation: fadeIn 0.3s ease-in-out;
}
plugin-generate-dist-102032 .alert-title {
  font-size: 18px;
  font-weight: 600;
  color: #991b1b;
}
plugin-generate-dist-102032 .publish-alert p {
  color: #7f1d1d;
  font-size: 14px;
  margin-bottom: 12px;
  line-height: 1.6;
}
plugin-generate-dist-102032 .publish-alert ul {
  margin: 10px 0 16px 18px;
  padding-left: 10px;
}
plugin-generate-dist-102032 .publish-alert li {
  font-size: 14px;
  color: #7f1d1d;
  margin-bottom: 8px;
  line-height: 1.5;
}
plugin-generate-dist-102032 .alert-question {
  font-weight: 600;
  margin-top: 12px;
  color: #991b1b;
}
@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(-5px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
plugin-generate-dist-102032 .publish-btn {
  position: relative;
  background: #2563eb;
  color: white;
  border: none;
  padding: 12px 24px;
  border-radius: 10px;
  font-weight: 500;
  font-size: 14px;
  cursor: pointer;
  transition: all 0.2s ease;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
}
plugin-generate-dist-102032 .publish-btn:hover {
  background: #1d4ed8;
}
plugin-generate-dist-102032 .publish-btn:disabled {
  background: #93c5fd;
  cursor: not-allowed;
}
plugin-generate-dist-102032 .loader {
  width: 16px;
  height: 16px;
  border: 2px solid rgba(255, 255, 255, 0.4);
  border-top: 2px solid #ffffff;
  border-radius: 50%;
  animation: spin 0.8s linear infinite;
  display: none;
}
plugin-generate-dist-102032 .publish-btn.loading .loader {
  display: inline-block;
}
plugin-generate-dist-102032 .publish-btn.loading .btn-text {
  opacity: 0.7;
}
@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}
plugin-generate-dist-102032 fieldset {
  border: 1px solid #e5e7eb;
  border-radius: 6px;
  padding: 16px 18px 18px;
  background: var(--bg-primary-color-darker);
  margin-bottom: 1rem;
}
plugin-generate-dist-102032 fieldset legend {
  padding: 0 6px;
  font-size: 14px;
  font-weight: 600;
  color: var(--text-primary-color);
}
plugin-generate-dist-102032 fieldset .description {
  opacity: 0.8;
  margin-top: 0.5rem;
  font-size: 12px;
  padding-left: 0.5rem;
  margin-bottom: 1rem;
}
plugin-generate-dist-102032 fieldset .field {
  display: flex;
  flex-direction: column;
  margin-top: 12px;
}
plugin-generate-dist-102032 fieldset .field label {
  font-size: 12px;
  font-weight: 500;
  margin-bottom: 4px;
  color: var(--text-primary-color-darker);
}
plugin-generate-dist-102032 fieldset .field input,
plugin-generate-dist-102032 fieldset .field select,
plugin-generate-dist-102032 fieldset .field textarea {
  padding: 7px 10px;
  font-size: 13px;
  border: 1px solid #d1d5db;
  border-radius: 4px;
  outline: none;
  background: #fff;
  color: #3f3e3e;
  transition: border-color 0.15s ease, box-shadow 0.15s ease;
}
plugin-generate-dist-102032 fieldset .field input:focus,
plugin-generate-dist-102032 fieldset .field select:focus,
plugin-generate-dist-102032 fieldset .field textarea:focus {
  border-color: #6366f1;
  box-shadow: 0 0 0 2px rgba(99, 102, 241, 0.15);
}
plugin-generate-dist-102032 fieldset .field input:disabled,
plugin-generate-dist-102032 fieldset .field select:disabled,
plugin-generate-dist-102032 fieldset .field textarea:disabled {
  background: #f3f4f6;
  color: var(--text-primary-color-disabled);
  cursor: not-allowed;
}
`);
        this.myState = {
            mode: '',
            newVersion: '',
            modeLang: '',
            languages: [],
            folders: { ori: '', dest: '' },
            pages: [],
            assets: [],
            actualtheme: 'Default',
            robots: '',
            folderRobots: '',
            folderSitemap: '',
            baseSitemap: ''
        };
        this.msg = messages['en'];
        this.publishModeOptions = [
            {
                value: "versioned-folder",
                label: "Versioned Folder",
                description: "Each deploy is published in its own folder, such as /version/123/."
            },
            {
                value: "hashed-assets",
                label: "Hashed Assets",
                description: "Stable paths with generated asset names, such as app.[hash].js."
            }
        ];
        this.completed = [];
        this.current = 1;
        this.mode = 'versioned-folder';
        this.newVersion = this.getLocalDateTime();
        this.modeLang = 'noLang';
        this.folders = { ori: 'www', dest: 'dist' };
        this.languages = [];
        this.pages = [];
        this.useRobots = true;
        this.useSiteMap = true;
        this.inPublish = false;
        this.clickedPublish = false;
        this.logs = [];
    }
    firstUpdated() {
        this.init();
    }
    async updated(changedProperties) {
        super.updated(changedProperties);
        const propMode = changedProperties.get('mode');
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
        <div class="agent-box">
            ${this.renderHeader()}
            ${this.renderWizard()}
            ${this.renderScenary()}
            
        </div> 
        `;
    }
    renderHeader() {
        return html `
            <header>
                <span class="svg-container">${pluginData.getSvg()}</span>
                <span>${pluginData.title} - ${mls.actualProject}</span>
            </header>
        `;
    }
    renderWizard() {
        return html `
            <div class="steps">
                <div class="step ${this.completed.includes(1) ? 'completed' : ''} ${this.current == 1 ? 'active' : ''}">
                    <div class="circle">1</div>
                    <span>${this.msg.step1}</span>
                </div>
                <div class="step ${this.completed.includes(2) ? 'completed' : ''} ${this.current == 2 ? 'active' : ''}">
                    <div class="circle">2</div>
                    <span>${this.msg.step2}</span>
                </div>
                <div class="step ${this.completed.includes(3) ? 'completed' : ''} ${this.current == 3 ? 'active' : ''}">
                    <div class="circle">3</div>
                    <span>${this.msg.step3}</span>
                </div>
            </div>
        `;
    }
    renderScenary() {
        switch (this.current) {
            case (1): return this.renderScenary1();
            case (2): return this.renderScenary2();
            case (3): return this.renderScenary3();
        }
    }
    renderScenary1() {
        const vlRobots = `
        User-agent: *\nAllow: /\n\n# Block only\nDisallow: /assets/\n\nSitemap: https://collab.codes/sitemap.xml
        `.trim();
        return html `
            <div class="content">
                <fieldset>
                    <legend>Folder</legend>
                    <div class="field">
                        <label>Folder origin</label>
                        <input value="www" @change=${(e) => this.folders.dest = e.target.value}></input>
                    </div>
                    <div class="field">
                        <label>Folder destiny</label>
                        <input value="dist" disabled></input>
                    </div>
                </fieldset>

                <fieldset>
                    <legend>Mode Build</legend>
                    <div class="field">
                        <label>Mode</label>
                        <select @change=${(e) => this.mode = e.target.value}>
                            <option value="versioned-folder">Versioned Folder</option>
                            <option value="hashed-assets">Hashed Assets</option>
                        </select>
                    </div>
                    <div class="description">
                        ${this.publishModeOptions.find((f) => f.value === this.mode)?.description}
                    </div>
                    <div class="field" style="display:${this.mode === 'versioned-folder' ? '' : 'none'}">
                        <label>New version</label>
                        <input value="${this.newVersion}"  disabled></input>
                    </div>
                </fieldset>

                <fieldset>
                    <legend>Mode Language</legend>
                    <div class="field">
                        <label>Mode</label>
                        <select @change=${(e) => this.modeLang = e.target.value}>
                            <option value="noLang">No language</option>
                            <option value="useLang">Use language</option>
                        </select>
                    </div>
                    ${this.modeLang === 'useLang' ? this.renderLang() : ''}
                </fieldset>

                <fieldset>
                    <legend>Robots</legend>
                    <div class="field">
                        <label>Use Robots</label>
                        <select @change=${(e) => this.useRobots = e.target.value === 'yes'}>
                            <option value="yes">Yes</option>
                            <option value="no">No</option>
                        </select>

                        <label style="margin-top:.5rem;display:${this.useRobots ? '' : 'none'}">Folder Robots</label>
                        <input id="iptRobots" value="en" type="text" style="display:${this.useRobots ? '' : 'none'}">

                        <label style="margin-top:.5rem;display:${this.useRobots ? '' : 'none'}">Content</label>
                        <textarea id="txtRobots" style="height:150px;display:${this.useRobots ? '' : 'none'}" >${vlRobots}</textarea>
                    </div>
                    
                </fieldset>

                <fieldset>
                    <legend>Sitemap</legend>
                    <div class="field">
                        <label>Use Sitemap</label>
                        <select @change=${(e) => { this.useSiteMap = e.target.value === 'yes'; }}>
                            <option value="yes">Yes</option>
                            <option value="no">No</option>
                        </select>

                        <label style="margin-top:.5rem;display:${this.useSiteMap ? '' : 'none'}">Folder Sitemap</label>
                        <input id="iptSitemap" value="en" type="text" style="display:${this.useSiteMap ? '' : 'none'}">

                        <label style="margin-top:.5rem;display:${this.useSiteMap ? '' : 'none'}">Base Sitemap</label>

                        <input id="iptBaseSitemap" value="https://www.collab.codes/" type="text" style="display:${this.useSiteMap ? '' : 'none'}">

                        
                    </div>
                    
                </fieldset>

                <div class="actions">
                    <button @click=${() => this.next(2)}>${this.msg.continue}</button>
                </div>
            
            </div>

        `;
    }
    renderLang() {
        return html `
        <div class="grid" style="margin-top:1rem">
            ${this.languages.map((l) => html `
                <label class="card" for="${l.name}">
                    <input type="checkbox" .info=${l} id="${l.name}"> ${l.name} <small>(path: "${l.path}")</small>
                </label>`)}

        </div>`;
    }
    renderScenary2() {
        return html `
            <div class="content"> 
                <div class="grid">
                    ${this.pages.map((p) => html `
                        <label class="card" for="${p.shortName}">
                            <input type="checkbox" .info=${p} id="${p.shortName}" checked> ${p.folder ? p.folder + '/' + p.shortName : p.shortName}
                        </label>`)}
                </div>
                <div class="actions">
                    <button @click=${() => this.next(1)} class="secondary">${this.msg.back}</button>
                    <button @click=${() => this.next(3)}>${this.msg.continue}</button>
                </div>
            </div>

        `;
    }
    renderScenary3() {
        return html `
            <div class="content"> 
                <div class="log-box" id="logBox">
                    ${this.logs.map((p) => unsafeHTML(p))}
                </div>
                <div class="actions">
                    <button @click=${() => this.next(2)} class="secondary" ?disabled=${this.inPublish}>${this.msg.back}</button>
                    <button @click=${this.startPublish} class="publish-btn ${this.inPublish ? 'loading' : ''}" style="display:${this.clickedPublish ? 'none' : ''}">
                        <span class="btn-text">${this.msg.publish}</span>
                        <span class="loader"></span>
                    </button>
                    <button @click=${this.fineshedPublish} class="publish-btn" style="display:${!this.clickedPublish ? 'none' : ''}">
                        <span class="btn-text">${this.msg.publishFinish}</span>
                    </button>
                </div>
            </div>

        `;
    }
    //-------IMPLEMENTATION-------
    async init() {
        await this.getLanguages();
        await this.getPages();
    }
    async getLanguages() {
        const info = await mls.l5.getProjectConf(mls.actualProject || 0);
        this.languages = info.languages;
    }
    async getPages() {
        const allItens = await getAllDefs();
        const pages = [];
        Object.keys(allItens).forEach((key) => {
            if (!allItens)
                return;
            const item = allItens[key];
            if (item.defs.meta.componentType === 'page') {
                const stor = mls.stor.files[key.replace('.defs', '')];
                if (stor && stor.project === mls.actualProject)
                    pages.push(stor);
            }
        });
        this.pages = pages;
    }
    getAssets() {
        const assets = [];
        Object.keys(mls.stor.files).forEach((key) => {
            const stor = mls.stor.files[key];
            if (stor.project === mls.actualProject && stor.level === 2 && stor.folder.startsWith(this.myState.folders.ori)) {
                const defsKey = mls.stor.getKeyToFile({ ...stor, extension: '.defs.ts' });
                if (mls.stor.files[defsKey])
                    return;
                assets.push(stor);
            }
        });
        this.myState.assets = assets;
    }
    next(scenary) {
        try {
            if (this.current === 1) {
                this.isValid1();
            }
            if (this.current === 2 && scenary > 2) {
                this.isValid2();
            }
            if (scenary === 1) {
                this.completed = [];
                this.useSiteMap = true;
                this.useRobots = true;
            }
            if (scenary === 2) {
                this.completed = [1];
            }
            if (scenary === 3) {
                this.logs = [`<div class="log-line log-info">[INFO] ${this.msg.clickInPublish}</div>`];
                this.completed = [1, 2];
            }
            this.current = scenary;
        }
        catch (e) {
            alert(e && e.message ? e.message : 'Error invalid step');
        }
    }
    isValid1() {
        if (!this.mode)
            throw new Error('Select a mode');
        this.myState.mode = this.mode;
        if (this.mode === 'versioned-folder' && !this.newVersion)
            throw new Error('Fill a new version');
        this.myState.newVersion = this.newVersion;
        if (!this.modeLang)
            throw new Error('Select a language mode');
        this.myState.modeLang = this.modeLang;
        if (this.modeLang === 'useLang') {
            const els = this.querySelectorAll('input:checked');
            if (els.length < 1)
                throw new Error(this.msg.errorLanguage);
            const infos = [];
            els.forEach((el) => {
                if (el.info)
                    infos.push(el.info);
            });
            if (infos.length < 1)
                throw new Error(this.msg.errorLanguage);
            this.myState.languages = infos;
        }
        if (this.folders.dest === '')
            throw new Error('Fill a folder dest');
        if (this.folders.ori === '')
            throw new Error('Fill a folder ori');
        if (this.useRobots && !this.txtRobots || (this.txtRobots && !this.txtRobots.value.trim())) {
            throw new Error('Fill a text robots');
        }
        if (this.useSiteMap && ((!this.iptSitemap || !this.iptBaseSitemap) || (this.iptBaseSitemap && !this.iptBaseSitemap.value))) {
            throw new Error('Fill a sitemap');
        }
        this.myState.folders.dest = this.folders.dest;
        this.myState.folders.ori = this.folders.ori;
        this.myState.robots = this.txtRobots ? this.txtRobots.value.trim() : '';
        this.myState.folderRobots = this.iptRobots && this.iptRobots.value ? this.iptRobots.value.trim() : '';
        this.myState.baseSitemap = this.iptBaseSitemap ? this.iptBaseSitemap.value.trim() : '';
        this.myState.folderSitemap = this.iptSitemap && this.iptSitemap.value ? this.iptSitemap.value.trim() : '';
        if (this.myState.baseSitemap.endsWith('/'))
            this.myState.baseSitemap = this.myState.baseSitemap.substring(0, this.myState.baseSitemap.length - 1);
    }
    isValid2() {
        const els = this.querySelectorAll('input:checked');
        if (els.length < 1)
            throw new Error(this.msg.errorPage);
        const infos = [];
        els.forEach((el) => {
            if (el.info)
                infos.push(el.info);
        });
        if (infos.length < 1)
            throw new Error(this.msg.errorPage);
        this.myState.pages = infos;
    }
    //---------------------------------------------------------
    //---------------------GENERATE DIST-----------------------
    //---------------------------------------------------------
    async startPublish() {
        if (this.inPublish)
            return;
        this.inPublish = true;
        await this.addLog(`${this.msg.startPublish} (${this.myState.pages.length} pages)...`, 'INFO');
        switch (this.myState.mode) {
            case ('versioned-folder'):
                await this.modeVersion();
                break;
            case ('hashed-assets'):
                await this.modeHash();
                break;
            default: await this.addLog(`This mode not implemented(${this.myState.mode})`, 'ERROR');
        }
        await this.addLog(this.msg.publishCompleted, 'SUCCESS');
        setTimeout(() => {
            this.clickedPublish = true;
            this.inPublish = false;
        }, 500);
    }
    fineshedPublish() {
        this.clickedPublish = false;
        this.myState = {
            mode: '',
            newVersion: '',
            modeLang: '',
            languages: [],
            folders: { ori: '', dest: '' },
            pages: [],
            assets: [],
            actualtheme: 'Default',
            robots: '',
            folderRobots: '',
            folderSitemap: '',
            baseSitemap: ''
        };
        this.next(1);
    }
    async modeVersion() {
        if (this.myState.modeLang === 'noLang') {
            await this.publishMyPages();
            await this.publishMyAssets();
            await this.createVersionFile();
            await this.createRobotsFile();
            await this.createSitemapFile();
            await this.updateVariable();
        }
        else {
            await this.addLog(`This language mode not implemented(${this.myState.modeLang})`, 'ERROR');
        }
    }
    async modeHash() {
        await this.addLog(`In development...`, 'ERROR');
    }
    async publishMyPages(lang = undefined) {
        let pages = [];
        for await (const stor of this.myState.pages) {
            const p = await this.publishPage(stor, lang);
            if (p) {
                pages.push(p);
            }
        }
        return pages;
    }
    async publishPage(stor, lang = undefined) {
        try {
            await this.addLog(`Compiling page: ${stor.folder ? stor.folder + '/' + stor.shortName : stor.shortName}`, 'INFO');
            let { project, shortName, folder } = stor;
            const content = await buildLandingPageByStor(stor, lang);
            let auxFolder = this.myState.folders.dest.endsWith('/') ? this.myState.folders.dest : this.myState.folders.dest + '/';
            folder = folder.replace(this.myState.folders.ori, '');
            if (this.myState.mode === 'versioned-folder') {
                auxFolder += this.myState.newVersion;
            }
            else {
                await this.addLog(`This mode not implemented(${this.myState.mode})`, 'ERROR');
                return undefined;
            }
            const param = {
                project,
                folder: folder.startsWith('/') ? auxFolder + folder : auxFolder + '/' + folder,
                shortName,
                level: 2,
                extension: '.html',
                source: content,
                status: 'new'
            };
            const info = await createStorFile(param, false, false, false);
            return info;
        }
        catch (e) {
            console.info(e);
            return undefined;
        }
    }
    async createVersionFile() {
        await this.addLog(`Creating version file...`, 'INFO');
        let project = mls.actualProject || 0;
        let level = 2;
        let shortName = 'version';
        let extension = '.json';
        let folder = 'dist';
        let content = `{"html":"${this.myState.newVersion}"}`;
        const key = mls.stor.getKeyToFile({ project, level, shortName, extension, folder });
        const stor = mls.stor.files[key];
        if (!stor) {
            const param = {
                project,
                folder,
                shortName,
                level,
                extension,
                source: content,
                status: 'new'
            };
            const info = await createStorFile(param, false, false, false);
            return info;
        }
        stor.status = 'changed';
        stor.updatedAt = new Date().toISOString();
        await mls.stor.localStor.setContent(stor, { content, contentType: 'string' });
    }
    async createRobotsFile() {
        if (!this.useRobots || !this.myState.robots)
            return;
        await this.addLog(`Creating robots file...`, 'INFO');
        let project = mls.actualProject || 0;
        let level = 2;
        let shortName = 'robots';
        let extension = '.txt';
        let folder = 'dist/' + this.myState.newVersion + (this.myState.folderRobots ? '/' + this.myState.folderRobots : '');
        let content = this.myState.robots;
        const param = {
            project,
            folder,
            shortName,
            level,
            extension,
            source: content,
            status: 'new'
        };
        const info = await createStorFile(param, false, false, false);
        return info;
    }
    async createSitemapFile() {
        if (!this.useSiteMap || !this.myState.baseSitemap)
            return;
        await this.addLog(`Creating sitemap file...`, 'INFO');
        let project = mls.actualProject || 0;
        let level = 2;
        let shortName = 'sitemap';
        let extension = '.xml';
        let folder = 'dist/' + this.myState.newVersion + (this.myState.folderSitemap ? '/' + this.myState.folderSitemap : '');
        const today = new Date().toISOString().split('T')[0];
        let content = `
<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    <url>
        <loc>${this.myState.baseSitemap}/</loc>
        <lastmod>${today}</lastmod>
        <priority>1.0</priority>
    </url>
    ${this.myState.pages.map((p) => {
            if (p.shortName === 'index')
                return '';
            const page = p.shortName + '.html';
            const pri = '0.5';
            return `<url>
    <loc>${this.myState.baseSitemap}/${page}</loc>
    <lastmod>${today}</lastmod>
    <priority>${pri}</priority>
  </url>`;
        })};
  
</urlset>
        `;
        const param = {
            project,
            folder,
            shortName,
            level,
            extension,
            source: content,
            status: 'new'
        };
        console.info(param);
        const info = await createStorFile(param, false, false, false);
        return info;
    }
    async publishMyAssets() {
        this.getAssets();
        for await (const f of this.myState.assets) {
            await this.publishAssets(f);
        }
    }
    async publishAssets(stor) {
        try {
            await this.addLog(`Create assets: ${stor.folder ? stor.folder + '/' + stor.shortName : stor.shortName}`, 'INFO');
            let { project, shortName, folder } = stor;
            let auxFolder = this.myState.folders.dest.endsWith('/') ? this.myState.folders.dest : this.myState.folders.dest + '/';
            folder = folder.replace(this.myState.folders.ori, '');
            if (this.myState.mode === 'versioned-folder') {
                auxFolder += this.myState.newVersion;
            }
            else {
                await this.addLog(`This mode not implemented(${this.myState.mode})`, 'ERROR');
                return undefined;
            }
            const params = {
                project,
                folder: folder.startsWith('/') ? auxFolder + folder : auxFolder + '/' + folder,
                shortName,
                level: 2,
                extension: stor.extension,
                versionRef: '0',
            };
            const file = await mls.stor.addOrUpdateFile(params);
            if (!file)
                throw new Error('[createStorFile] Invalid storFile');
            file.status = 'new';
            const fileInfo = {
                content: await stor.getContent(),
                contentType: 'blob'
            };
            await mls.stor.localStor.setContent(file, fileInfo);
            await mls.stor.cache.addIfNeed({ ...file, content: fileInfo.content, contentType: fileInfo.contentType, version: '0' });
            return file;
        }
        catch (e) {
            console.info(e);
            return undefined;
        }
    }
    async updateVariable() {
        const variableName = await this.getVariableByProject(mls.actualProject || 0);
        if (!variableName)
            return;
        await this.addLog(`Update variable: ${variableName}`, 'INFO');
        const driver = await mls.stor.others.getDefaultDriver(mls.actualProject || 0);
        if (!variableName || !driver.updateVariable)
            return;
        await driver.updateVariable(variableName, this.myState.newVersion);
    }
    async getVariableByProject(project) {
        if (!project)
            return;
        const url = `/_${project}_/l2/project.js`;
        try {
            const modulePrj = await import(url);
            if (!modulePrj || !modulePrj.projectConfig || !modulePrj.projectConfig.masterFrontEnd || !modulePrj.projectConfig.masterFrontEnd.variableVersion)
                return;
            return modulePrj.projectConfig.masterFrontEnd.variableVersion;
        }
        catch (err) {
            console.error('no find project config');
            return;
        }
    }
    async addLog(msg, tp) {
        let str = '';
        if (tp === 'INFO') {
            str = `<div class="log-line log-info">[INFO] ${msg}</div>`;
        }
        else if (tp === 'SUCCESS') {
            str = `<div class="log-line log-success">[SUCCESS] ${msg}</div>`;
        }
        else if (tp === 'ERROR') {
            str = `<div class="log-line log-error">[ERROR] ${msg}</div>`;
        }
        else {
            str = `<div class="log-line">[MESSAGE] ${msg}</div>`;
        }
        this.logs = [...this.logs, str]; // IMPORTANTE: nova referência
        await this.waitRender(); // 🔥 deixa o browser pintar
        if (this.logBox) {
            this.logBox.scrollTop = this.logBox.scrollHeight;
        }
    }
    getLocalDateTime() {
        const now = new Date();
        const pad = (n) => String(n).padStart(2, '0');
        const year = now.getFullYear();
        const month = pad(now.getMonth() + 1);
        const day = pad(now.getDate());
        const hour = pad(now.getHours());
        const min = pad(now.getMinutes());
        const sec = pad(now.getSeconds());
        return `${year}${month}${day}${hour}${min}${sec}`;
    }
    async waitRender() {
        await new Promise(requestAnimationFrame);
    }
}
__decorate([
    state()
], PluginGenerateDist.prototype, "completed", void 0);
__decorate([
    state()
], PluginGenerateDist.prototype, "current", void 0);
__decorate([
    state()
], PluginGenerateDist.prototype, "mode", void 0);
__decorate([
    state()
], PluginGenerateDist.prototype, "newVersion", void 0);
__decorate([
    state()
], PluginGenerateDist.prototype, "modeLang", void 0);
__decorate([
    state()
], PluginGenerateDist.prototype, "folders", void 0);
__decorate([
    state()
], PluginGenerateDist.prototype, "languages", void 0);
__decorate([
    state()
], PluginGenerateDist.prototype, "pages", void 0);
__decorate([
    state()
], PluginGenerateDist.prototype, "useRobots", void 0);
__decorate([
    state()
], PluginGenerateDist.prototype, "useSiteMap", void 0);
__decorate([
    state()
], PluginGenerateDist.prototype, "inPublish", void 0);
__decorate([
    state()
], PluginGenerateDist.prototype, "clickedPublish", void 0);
__decorate([
    state()
], PluginGenerateDist.prototype, "logs", void 0);
__decorate([
    query('#logBox')
], PluginGenerateDist.prototype, "logBox", void 0);
__decorate([
    query('#txtRobots')
], PluginGenerateDist.prototype, "txtRobots", void 0);
__decorate([
    query('#iptRobots')
], PluginGenerateDist.prototype, "iptRobots", void 0);
__decorate([
    query('#iptSitemap')
], PluginGenerateDist.prototype, "iptSitemap", void 0);
__decorate([
    query('#iptBaseSitemap')
], PluginGenerateDist.prototype, "iptBaseSitemap", void 0);
if (!customElements.get('plugin-generate-dist-102032')) {
    customElements.define('plugin-generate-dist-102032', PluginGenerateDist);
}
export const pluginData = {
    title: "Generate Dist",
    getSvg() {
        return svg `
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640"><!--!Font Awesome Free v7.2.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2026 Fonticons, Inc.--><path d="M352 173.3L352 384C352 401.7 337.7 416 320 416C302.3 416 288 401.7 288 384L288 173.3L246.6 214.7C234.1 227.2 213.8 227.2 201.3 214.7C188.8 202.2 188.8 181.9 201.3 169.4L297.3 73.4C309.8 60.9 330.1 60.9 342.6 73.4L438.6 169.4C451.1 181.9 451.1 202.2 438.6 214.7C426.1 227.2 405.8 227.2 393.3 214.7L352 173.3zM320 464C364.2 464 400 428.2 400 384L480 384C515.3 384 544 412.7 544 448L544 480C544 515.3 515.3 544 480 544L160 544C124.7 544 96 515.3 96 480L96 448C96 412.7 124.7 384 160 384L240 384C240 428.2 275.8 464 320 464zM464 488C477.3 488 488 477.3 488 464C488 450.7 477.3 440 464 440C450.7 440 440 450.7 440 464C440 477.3 450.7 488 464 488z"/></svg>
    `;
    }
};
