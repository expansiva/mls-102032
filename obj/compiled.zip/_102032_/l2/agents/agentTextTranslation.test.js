/// <mls fileReference="_102032_/l2/agents/agentTextTranslation.test.ts" enhancement="_blank"/>
export const integrations = [];
export const tests = [];
