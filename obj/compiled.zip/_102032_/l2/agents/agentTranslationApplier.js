/// <mls fileReference="_102032_/l2/agents/agentTranslationApplier.ts" enhancement="_blank"/>
import { replaceTripleslashAndTag } from '/_100554_/l2/collabLibStor.js';
export function createAgent() {
    return {
        agentName: "agentTranslationApplier",
        agentProject: 102032,
        agentFolder: "",
        agentDescription: "Agent for apply translation html",
        visibility: "public",
        beforePromptImplicit,
        beforePromptStep,
        afterPromptStep
    };
}
async function beforePromptImplicit(agent, context, userPrompt) {
    if (!userPrompt || userPrompt.length < 5)
        throw new Error('invalid prompt');
    const addMessageAI = {
        type: "add-message-ai",
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [{
                    type: "system",
                    content: system1,
                }, {
                    type: "human",
                    content: context.message.content
                }],
            taskTitle: `Translate texts`,
            threadId: context.message.threadId,
            userMessage: context.message.content,
        }
    };
    return [addMessageAI];
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    if (!args)
        throw new Error(`[beforePromptStep] args invalid`);
    const continueParallel = {
        type: "prompt_ready",
        args,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        hookSequential,
        parentStepId: parentStep.stepId,
        humanPrompt: args || '',
        systemPrompt: system1
    };
    return [continueParallel];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    if (!agent || !context || !step)
        throw new Error(`[afterPromptStep] invalid params, agent:${!!agent}, context:${!!context}, step:${!!step}`);
    const payload = (step.interaction?.payload?.[0]);
    if (payload?.type !== 'flexible' || !payload.result)
        throw new Error(`[afterPromptStep] invalid payload: ${payload}`);
    let status = 'completed';
    let intents = [];
    const output = payload.result;
    if (!context.task?.iaCompressed?.longMemory)
        throw new Error(`[afterPromptStep] invalid long memory`);
    const { targetFolder, project, fileReference, originFolder } = context.task?.iaCompressed?.longMemory;
    if (!targetFolder || !project || !fileReference || !originFolder)
        throw new Error(`[afterPromptStep] invalid long memory`);
    console.log("=== Output ");
    console.info({ html: decodeHtml(output), targetFolder, project, fileReference, originFolder });
    await createFiles(decodeHtml(output), targetFolder, +project, fileReference, originFolder);
    const updateStatus = {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        status
    };
    return [updateStatus];
}
async function createFiles(html, targetFolder, project, fileReference, originFolder) {
    const files = Object.values(mls.stor.files).filter((file) => file.folder === originFolder && file.project === project);
    for (let file of files) {
        const storFileNew = await duplicateFile(file, targetFolder);
        const ref = mls.stor.convertFileToFileReference(file);
        const refNew = mls.stor.convertFileToFileReference(storFileNew);
        if (ref === fileReference.replace('.ts', '.html')) {
            // const storFileNew = await duplicateFile(file, targetFolder);
            // const refNew = mls.stor.convertFileToFileReference(storFileNew);
            console.info(`===update file :${refNew}`);
            await updateHtml(storFileNew, html);
        }
    }
}
async function duplicateFile(storFile, newFolder) {
    const keyToNewFile = mls.stor.getKeyToFile({ ...storFile, folder: newFolder });
    const storFileDist = mls.stor.files[keyToNewFile];
    if (storFileDist)
        return storFileDist;
    console.info(`===duplicate file :${keyToNewFile}`);
    let source = await storFile.getContent();
    if (!source)
        throw new Error('[migrateFile] Impossible rename this file:' + storFile.shortName);
    if (!newFolder)
        newFolder = storFile.folder;
    if (storFile.level === 2 && typeof source === 'string') {
        source = replaceTripleslashAndTag(storFile, storFile.project, storFile.shortName, newFolder, source);
    }
    const file = await createStorFile({
        project: storFile.project,
        shortName: storFile.shortName,
        level: storFile.level,
        folder: newFolder,
        content: source,
        extension: storFile.extension,
        versionRef: '0'
    });
    return file;
}
async function updateHtml(storFile, newHtml) {
    const modelDefs = await storFile.getOrCreateModel();
    modelDefs.model.setValue(newHtml);
}
async function createStorFile(params) {
    const file = await mls.stor.addOrUpdateFile(params);
    if (!file)
        throw new Error('Invalid storFile');
    file.status = 'new';
    const fileInfo = {
        content: params.content,
        contentType: typeof params.content === 'string' ? 'string' : 'blob',
    };
    file.updatedAt = new Date().toISOString();
    await mls.stor.localStor.setContent(file, fileInfo);
    file.inLocalStorage = true;
    return file;
}
function decodeHtml(html) {
    return html
        .replace(/&lt;/g, "<")
        .replace(/&gt;/g, ">")
        .replace(/&quot;/g, '"')
        .replace(/&amp;/g, "&");
}
const system1 = `
<!-- modelType: codeflash -->

You are an agent responsible for applying translations to HTML.

Your task is to receive:
1. The original HTML
2. A list of translated texts

You must replace the original texts with their translations in the HTML.

IMPORTANT RULES:

- NEVER modify the HTML structure.
- NEVER change or remove tags.
- NEVER modify attributes.
- ONLY replace text nodes.
- Preserve whitespace when possible.
- If a text appears multiple times, replace all occurrences.
- If a translation is missing, keep the original text.
- Do NOT translate anything yourself. Only apply provided translations.

Examples:

Original HTML:
<div><h1>Welcome</h1></div>

Translations:
Welcome → Bem-vindo

Result:
<div><h1>Bem-vindo</h1></div>

Do NOT modify:

- tag names
- attributes
- class names
- ids
- scripts
- styles

Return only valid JSON.

## Output format
You must return the object strictly as JSON

export type Output = {
    type: "flexible";
    result: string;
};

`;
