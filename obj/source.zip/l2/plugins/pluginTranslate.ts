/// <mls fileReference="_102032_/l2/plugins/pluginTranslate.ts" enhancement="_102027_/l2/enhancementLit"/>

import { html, svg, TemplateResult } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102027_/l2/stateLitElement.js';

/// **collab_i18n_start**
const message_pt = {
    title: 'Configuração do Tradutor',
    project: 'Projeto',
    originFolder: 'Pasta de Origem',
    targetFolder: 'Pasta de Destino',
    originLanguage: 'Idioma de Origem',
    targetLanguage: 'Idioma de Destino',
    excludeFiles: 'Arquivos a Excluir (separados por vírgula)',
    pages: 'Somente Páginas (separadas por vírgula)',
    generatedPrompt: 'Prompt Gerado',
    copy: 'Copiar'
}

const message_en = {
    title: 'Translator Configuration',
    project: 'Project',
    originFolder: 'Origin Folder',
    targetFolder: 'Target Folder',
    originLanguage: 'Origin Language',
    targetLanguage: 'Target Language',
    excludeFiles: 'Exclude Files (comma separated)',
    pages: 'Only Pages (comma separated)',
    generatedPrompt: 'Generated Prompt',
    copy: 'Copy'
}

type MessageType = typeof message_en;

const messages: { [key: string]: MessageType } = {
    'en': message_en,
    'pt': message_pt
}
/// **collab_i18n_end**

@customElement('plugins--plugin-translate-102032')
export class PluginTranslate100554 extends StateLitElement {

    private msg: MessageType = messages['en'];

    @state() project = 102031;
    @state() originFolder = 'www/en';
    @state() targetFolder = 'www/pt';
    @state() originLanguage = 'en';
    @state() targetLanguage = 'pt';

    @state() excludeFiles = '';
    @state() pages = '';

    private generatePrompt() {

        const config: any = {
            targetLanguage: this.targetLanguage,
            targetFolder: this.targetFolder,
            originFolder: this.originFolder,
            originLanguage: this.originLanguage,
            project: Number(this.project)
        };

        if (this.pages.trim()) {
            config.pages = this.pages.split(',').map(v => v.trim());
        } else if (this.excludeFiles.trim()) {
            config.excludeFiles = this.excludeFiles.split(',').map(v => v.trim());
        }

        return `@@agentTextExtractor ${JSON.stringify(config)}`;
    }

    render() {

        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];

        const prompt = this.generatePrompt();

        return html`

        <div class="container">

            <h3>${this.msg.title}</h3>

            <label>${this.msg.project}</label>
            <input type="number"
                .value=${this.project}
                @input=${(e: any) => this.project = e.target.value}>

            <label>${this.msg.originFolder}</label>
            <input
                .value=${this.originFolder}
                @input=${(e: any) => this.originFolder = e.target.value}>

            <label>${this.msg.targetFolder}</label>
            <input
                .value=${this.targetFolder}
                @input=${(e: any) => this.targetFolder = e.target.value}>

            <label>${this.msg.originLanguage}</label>
            <input
                .value=${this.originLanguage}
                @input=${(e: any) => this.originLanguage = e.target.value}>

            <label>${this.msg.targetLanguage}</label>
            <input
                .value=${this.targetLanguage}
                @input=${(e: any) => this.targetLanguage = e.target.value}>

            <label>${this.msg.excludeFiles}</label>
            <input
                .value=${this.excludeFiles}
                @input=${(e: any) => this.excludeFiles = e.target.value}>

            <label>${this.msg.pages}</label>
            <input
                .value=${this.pages}
                @input=${(e: any) => this.pages = e.target.value}>

            <h4>${this.msg.generatedPrompt}</h4>

            <pre>${prompt}</pre>

            <button
                @click=${() => navigator.clipboard.writeText(prompt)}>
                ${this.msg.copy}
            </button>

        </div>

        `;
    }
}

export const pluginData: mls.plugin.IPluginData = {
    title: "Translate",
    getSvg(): TemplateResult {
        return svg`
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 110.94 122.88"><title>lookup</title><path fill="currentColor" d="M19.26,40.53a2.74,2.74,0,0,1-2.59-2.82,2.69,2.69,0,0,1,2.59-2.82H63.41A2.72,2.72,0,0,1,66,37.71a2.68,2.68,0,0,1-2.58,2.82ZM79.41,66a24.82,24.82,0,0,1,20.78,38.41l10.75,11.71-7.42,6.77-10.36-11.4A24.82,24.82,0,1,1,79.41,66Zm13.2,11.62a18.66,18.66,0,1,0,5.47,13.2,18.66,18.66,0,0,0-5.47-13.2Zm-73.32-22a2.73,2.73,0,0,1-2.58-2.82A2.68,2.68,0,0,1,19.29,50H41.37A2.74,2.74,0,0,1,44,52.84a2.68,2.68,0,0,1-2.58,2.82ZM82.76,17.14H92a6.64,6.64,0,0,1,6.61,6.61V55.18c-.2,2.07-5.27,2.1-5.7,0V23.75a.92.92,0,0,0-.94-.94H82.73V55.18c-.49,1.88-4.72,2.16-5.67,0V6.61a.92.92,0,0,0-.94-.94H6.58a1,1,0,0,0-.68.27,1,1,0,0,0-.26.67V85.18a1,1,0,0,0,.26.67,1,1,0,0,0,.68.27H43.36c2.86.29,3,5.23,0,5.67H21.5v10.53a.92.92,0,0,0,.94.94H43.36c2.07.23,2.74,4.94,0,5.67H22.48a6.62,6.62,0,0,1-6.61-6.61V91.79H6.61a6.49,6.49,0,0,1-4.66-2A6.56,6.56,0,0,1,0,85.18V6.61A6.49,6.49,0,0,1,2,2,6.55,6.55,0,0,1,6.61,0H76.16a6.51,6.51,0,0,1,4.66,2,6.54,6.54,0,0,1,1.94,4.66V17.14ZM19.26,25.4a2.74,2.74,0,0,1-2.59-2.82,2.69,2.69,0,0,1,2.59-2.82H63.41A2.73,2.73,0,0,1,66,22.58a2.69,2.69,0,0,1-2.58,2.82Z"/></svg>
    `;
    }
};